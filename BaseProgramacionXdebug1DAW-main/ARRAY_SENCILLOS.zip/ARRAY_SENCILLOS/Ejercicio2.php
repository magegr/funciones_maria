<!DOCTYPE html>
<html>
<head>
    <title>EJEMPLOS SENCILLOS ARRAYS</title>
</head>
<body>
    <h1>EJEMPLOS SENCILLOS ARRAYS</h1>

    <?php
    echo "ENCONTRAR UN NÚMERO<br>";
    //Ejemplo uni-dimensional indexado
    //Array donde se muestran los números de la lotería de Navidad.
    //Encuentra un número en el array mediante un bucle foreach.
    $numeros = [12345, 67890, 54321, 98765]; //array de números
    $numero = 54321; //número a buscar

    foreach ($numeros as $value){
        if ($value==$numero){
            echo "Te ha tocado la lotería";
        }
    }
       
    ?>
    </body>
    </html>